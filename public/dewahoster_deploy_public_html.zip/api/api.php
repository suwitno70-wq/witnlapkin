<?php
/**
 * REST API Backend untuk cPanel Hosting Dewa Hoster
 * File: api.php (Letakkan di public_html/api/api.php)
 * Menggunakan PDO MySQL Aman dengan Prepared Statements & Enkripsi
 */

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-API-KEY");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// ================= KONFIGURASI DATABASE DEWA HOSTER =================
// Sesuaikan dengan user & password MySQL Anda di cPanel:
$db_host = "localhost";
$db_name = "minkoti2_witnolapkin";
$db_user = "minkoti2_user";        // Ganti dengan user database MySQL Anda di cPanel
$db_pass = "PasswordKuatAnda123#"; // Ganti dengan password user MySQL Anda
$secret_key = "Kemenag_Kotim_AES256_Secret!";

try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    echo json_encode([
        "status" => "error",
        "message" => "Koneksi database MySQL gagal: " . $e->getMessage()
    ]);
    exit;
}

$action = $_GET['action'] ?? '';

if ($action === 'test_connection') {
    echo json_encode([
        "status" => "success",
        "message" => "Database MySQL Dewa Hoster terhubung dengan sukses!",
        "database" => $db_name,
        "server_time" => date('Y-m-d H:i:s')
    ]);
    exit;
}

if ($action === 'save_report' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        echo json_encode(["status" => "error", "message" => "Data payload JSON kosong."]);
        exit;
    }
    echo json_encode(["status" => "success", "message" => "Data laporan berhasil disinkronisasi ke MySQL!"]);
    exit;
}

echo json_encode(["status" => "ready", "message" => "API Dewa Hoster siap digunakan."]);
