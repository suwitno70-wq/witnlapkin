-- ============================================================
-- SKEMA TABEL MYSQL LAPORAN KINERJA GURU (DEWA HOSTER CPANEL)
-- Kompatibel Penuh: phpMyAdmin Shared Hosting (Tanpa Error #1044)
-- ============================================================
-- PETUNJUK:
-- Di phpMyAdmin, klik database 'minkoti2_witnolapkin' di panel kiri,
-- lalu klik Import dan jalankan file SQL ini.
-- ============================================================

CREATE TABLE IF NOT EXISTS `tb_profil_pegawai` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `tipe_pegawai` ENUM('guru', 'kepala') NOT NULL,
  `nama` VARCHAR(255) NOT NULL,
  `nip` VARCHAR(100) NOT NULL,
  `pangkat_golongan` VARCHAR(100) NULL,
  `jabatan` VARCHAR(255) NOT NULL,
  `unit_kerja` VARCHAR(255) NOT NULL,
  `tanda_tangan_data` LONGTEXT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_tipe` (`tipe_pegawai`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tb_periode_laporan` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `bulan` VARCHAR(50) NOT NULL,
  `tahun` INT NOT NULL,
  `status_kunci` TINYINT(1) DEFAULT 0,
  `nomor_se_lampiran1` VARCHAR(255) DEFAULT 'AJ/B.II.2/Kp.02.3/488/2015',
  `nomor_se_lampiran2` VARCHAR(255) DEFAULT 'Kep.Sekjen Kemenag Nomor 83 Tahun 2019',
  `kota_penandatanganan` VARCHAR(100) DEFAULT 'Sampit',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_periode` (`bulan`, `tahun`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tb_lampiran1_harian` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `periode_id` INT NOT NULL,
  `hari` VARCHAR(20) NOT NULL,
  `tanggal` VARCHAR(20) NOT NULL,
  `kategori` ENUM('Mengajar', 'Kepanitiaan', 'Kegiatan Lainnya') NOT NULL DEFAULT 'Mengajar',
  `uraian_kegiatan` TEXT NOT NULL,
  `output_bukti` VARCHAR(100) DEFAULT 'Dokumen',
  `urutan` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_periode` (`periode_id`),
  INDEX `idx_kategori` (`kategori`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tb_lampiran2_bulanan` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `periode_id` INT NOT NULL,
  `uraian_kegiatan` VARCHAR(255) NOT NULL,
  `kategori` VARCHAR(50) DEFAULT 'Kegiatan',
  `volume` INT NOT NULL DEFAULT 1,
  `satuan` VARCHAR(50) DEFAULT 'Kegiatan',
  `bukti_dokumen` VARCHAR(100) DEFAULT 'Dokumen',
  `is_auto` TINYINT(1) DEFAULT 1,
  `urutan` INT DEFAULT 0,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_periode_l2` (`periode_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
